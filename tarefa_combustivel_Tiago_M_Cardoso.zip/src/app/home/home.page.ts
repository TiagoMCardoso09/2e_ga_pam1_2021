import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  combustiveis = [
    'duvida.webp',
    'etanol.jpg',
    'gasolina.webp',
    'livreEscolha.jpg',
    'erro.jpeg'
  ];

  resultado = [
    '',
    'positivo',
    'negativo'
  ];

  resultados = [
    'Insira os valores',
    'O ETANOL está mais viável!',
    'A GASOLINA está mais viável!',
    'Você pode decidir, os dois estão com a mesma viabilidade!',
    'Você não inseriou nenhum valor! Por gentileza, informe dois valores válidos!',
    'Você não inseriou o valor do ETANOL',
    'Você não inseriou o valor da GASOLINA!'
  ];

  alerta = [
    'txtAlerta',
    'txtErro'
  ];

  imgDecisao      = this.combustiveis[0];
  txtDecisao      = this.resultados[0];
  configEtanol    = this.resultado[0];
  configGasolina  = this.resultado[0];
  configAlerta    = this.alerta[0];


  valorEtanol:      number;
  valorGasolina:    number;
  valorDecisao:     number;
  valorImgDecisao:  number;
  valorTxtDecisao:  number;
  valorResultE:     number;
  valorResultG:     number;
  valorAlerta:      number;

  constructor() {}


  decisao(): void{
    this.valorResultG = 0;
    this.valorResultE = 0;

    this.valorDecisao = this.valorEtanol/this.valorGasolina;

    if(this.valorEtanol == null && this.valorGasolina == null || this.valorEtanol === 0 && this.valorGasolina === 0){
      this.valorImgDecisao = 4;
      this.valorTxtDecisao = 4;
      this.valorResultE    = 2;
      this.valorResultG    = 2;
      this.valorAlerta     = 1;
    } else if(this.valorEtanol == null || this.valorEtanol === 0){
        this.valorImgDecisao = 4;
        this.valorTxtDecisao = 5;
        this.valorResultE     = 2;
        this.valorAlerta     = 1;
      } else if(this.valorGasolina == null || this.valorGasolina === 0){
          this.valorImgDecisao = 4;
          this.valorTxtDecisao = 6;
          this.valorResultG   = 2;
          this.valorAlerta     = 1;
        } else if(this.valorDecisao < 0.7){
            this.valorImgDecisao = 1;
            this.valorTxtDecisao = 1;
            this.valorResultE     = 1;
            this.valorAlerta     = 0;
          } else if(this.valorDecisao > 0.7){
              this.valorImgDecisao = 2;
              this.valorTxtDecisao = 2;
              this.valorResultG   = 1;
              this.valorAlerta     = 0;
            } else if(this.valorDecisao === 0.7){
                this.valorImgDecisao = 3;
                this.valorTxtDecisao = 3;
                this.valorResultE     = 1;
                this.valorResultG   = 1;
                this.valorAlerta     = 0;
              } else {
                alert('Parabéns, você conseguiu crashar o programa!!!');
              }

    this.imgDecisao     = this.combustiveis[this.valorImgDecisao];
    this.txtDecisao     = this.resultados[this.valorTxtDecisao];
    this.configEtanol   = this.resultado[this.valorResultE];
    this.configGasolina = this.resultado[this.valorResultG];
    this.configAlerta   = this.alerta[this.valorAlerta];
  }
}
